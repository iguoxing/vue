<template>
<!-- <div class="toolbar flex">
  <div class="first-btn">发起审批</div>
  <div class="division"></div>
  <div class="first-tab active">资源包购买记录</div>
  <div class="first-tab">资源包消耗明细</div>
  <div class="first-tab">抄送我的
    <span class="prompt">1</span>
  </div>
</div> -->

<div class="toolbar ad-flex exam">
        <!-- <div class="first-btn">发起审批</div> -->
        <div class="first-btn active">发起审批</div>
        <div class="division"></div>
        <div class="first-tab" toggle-id="achiTab">待我审批的</div>
        <div class="first-tab" toggle-id="spreadTab">我已审批的</div>
        <div class="first-tab" toggle-id="spreadTab">我发起的</div>
        <div class="first-tab">抄送我的
            <span class="prompt">1</span>
        </div>
</div>
</template>
<style scoped>
 @import "../../assets/css/css.css"; 
</style>
