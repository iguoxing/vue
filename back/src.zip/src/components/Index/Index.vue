<template>
<!-- <h1>{{msg}}</h1> -->
    <div id="example" class="height-max">   
    <!-- <div id="example" class="flex">    -->
        <my-toolbar></my-toolbar> 
        <my-leftbar></my-leftbar>                  
        <my-content></my-content>                                   
        <!-- <my-approval></my-approval>                                    -->
        <!-- <my-application></my-application>                                    -->
    </div>

</template>

<script>
export default {
  name: 'index',
  data () {
    return {
      msg: 'Welcome'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 @import "../../assets/css/css.css"; 
</style>
