<template>
<div>
  <div class="frame">
    <div class="left-side ad-flex sidebar-shrink">
        <div class="first-level">
            <div class="left-case-1 side-shadow">
              <a href="http://work.duodian.com/main"><img class="head" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_main.png"></a>
            </div>
            <div class="left-case-1 sidebar-fold side-shadow">
              <img class="icon" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_display.png">
              <!-- <img class="icon" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_shrink.png"> -->
            </div>
            <div class="left-case side-shadow">
                <img class="head" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/default.jpg">
            </div>
            <div class="left-case side-shadow active">
                <img class="icon" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_itry.png">
            </div>
            <div class="left-case side-shadow">
              <img class="icon" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_bao.png">
            </div>
            <div class="left-case-1 sidebar-bottom">
              <a class="ad-flex" href="http://work.duodian.com/layout"><img class="icon" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_exit.png"></a>
            </div>
        </div>
        <div class="second-level">
            <div class="currunt-title side-shadow"><span>应用试客</span></div>
            <div class="heigth-10"></div>
            <div class="first-title">
              <i class="glyphicon glyphicon-th-large"></i>
              <span>概览</span>
            </div>
            <div class="first-title">
              <i class="glyphicon glyphicon-file"></i>
              <span>业务查询</span>
            </div>
            <div class="first-title active">
              <i class="glyphicon glyphicon-file"></i>
              <span>财务数据</span>
            </div>
            <div class="second-list">
              <div class="second-title">
                <i class="dot"></i>
                <span>发票流量</span>
              </div>
              <div class="second-title active">
                <i class="dot"></i>
                <span>财务流水</span>
              </div>
              <div class="second-title">
                <i class="dot"></i>
                <span>汇款底单</span>
              </div>
              <div class="second-title">
                <i class="dot"></i>
                <span>结算单</span>
              </div>
            </div>
            <div class="first-title">
              <i class="glyphicon glyphicon-user"></i>
              <span>客户管理</span>
            </div>
        </div>
    </div>
    <div class="frame-setting flex-col-center">
      <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/settings_icon.png">
      <span class="bottom-title">个人设置</span>
      <div class="bottom-dialog">
        <div class="class-a">
          <div class="menu-title">个人信息</div>
          <div class="menu-title">密码修改</div>
          <div class="menu-title">绑定微信</div>
          <div class="menu-title">帮助文档</div>
        </div>
        <div class="class-b">注销登录</div>
      </div>
    </div>

    
    <!-- <h1>{{ msg }}</h1>
    <h2>AdMore</h2> -->

</div>
  
</div>
</template>

<script>
export default {
  name: 'index',
  data () {
    return {
      msg: 'Welcome'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 @import "../../assets/css/css.css"; 
</style>
