<template>
  <div class="symbol">

      <h1>{{ msg }}</h1>
      <h2>work</h2>

  </div>
</template>

<script>
export default {
  name: 'symbol',
  data () {
    return {
      msg: 'symbol'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
