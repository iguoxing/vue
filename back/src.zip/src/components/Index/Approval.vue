<template>
<div class="center-content">
  <div class="project-list flex-wrap">
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_1.png">
          <span class="item-title">发票申请</span>
        </div>
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_2.png">
          <span class="item-title">特批申请</span>
        </div>
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_3.png">
          <span class="item-title">代金券申请</span>
        </div>
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_4.png">
          <span class="item-title">汇款底单</span>
        </div>
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_5.png">
          <span class="item-title">合同审批</span>
        </div>
        <div class="item-info">
          <img src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/approval/approval_icon_6.png">
          <span class="item-title">客户录入</span>
        </div>
  </div>
</div>
</template>
<style scoped>
 @import "../../assets/css/css.css"; 
</style>
