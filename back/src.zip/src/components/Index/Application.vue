<template>
<div class="center-content">
  <div class="application-form">
    <div class="form-frame">
      <div class="form-title ad-flex">
        <div class="second-tab active">发票申请</div>
        <div class="second-tab">特批申请</div>
        <div class="second-tab">代金券申请</div>
        <div class="second-tab">汇款底单</div>
        <div class="second-tab">合同审批</div>
        <div class="second-tab">客户录入</div>
      </div>
      <div class="form-notice margin-top-3 flex-col-center">
        <div class="notice-des margin-left-3">这是本月第 5 次发票申请</div>
        <div class="notice-record margin-right-3">查看记录</div>
      </div>
      <div class="form-list">
        <div class="form-item flex-col-center">
          <div class="item-title">发票类型</div>    
          <div class="item-des">预开发票</div>    
        </div>
        <div class="form-divider"></div>
        <div class="form-item flex-col-center">
          <div class="item-title">申请客户</div>    
          <div class="item-select flex-col-center">
            <div>选填</div>
            <div><img class="item-arrow" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_arrow_down.png"/></div>
          </div>    
        </div>
        <div class="form-divider"></div>
        <div class="form-item flex-col-center">
          <div class="item-title">审批人</div>    
          <div class="item-select flex-col-center">
            <div>选填</div>
            <div><img class="item-arrow" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_arrow_down.png"/></div>
          </div>    
        </div>
        <div class="form-divider"></div>
        <div class="form-item form-remark">
          <div class="item-title">备注</div>    
          <div class="item-remark">
            <textarea class="textarea-remark" onfocus="if(value=='200字以内'){value=''}"  
    onblur="if (value ==''){value='200字以内'}">200字以内
            </textarea>
          </div>    
        </div>
        <div class="form-divider"></div>
        <div class="form-item flex-col-center">
          <div class="item-title">抄送人</div>    
          <div class="item-select flex-col-center">
            <div>选填</div>
            <div><img class="item-arrow" src="https://admore-cas.oss-cn-hangzhou.aliyuncs.com/admin/img/common/icon_arrow_down.png"/></div>
          </div>    
        </div>
        <div class="form-item flex-col-center">
          <div class="item-title"></div>    
          <div class="form-button">
            <button class="btn-primary">创建</button>
            <button class="btn-primary disabled margin-left-3">取消</button>
          </div>    
        </div>
        

      </div>
    </div>
      
  </div>
</div>
</template>
<style scoped>
 @import "../../assets/css/css.css"; 
</style>
