import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Index from '@/components/Index/Index' 
import Symbols from '@/components/Index/Symbols'
import Toolbar from '@/components/Index/Toolbar'
import Left from '@/components/Index/Left'
import Content from '@/components/Index/Content'
import Approval from '@/components/Index/Approval'
import Application from '@/components/Index/Application'

Vue.use(Router)
export default new Router({
  // 选中状态
  linkActiveClass:'active',
  mode: 'history',
  // scrollBehavior: () => ({ y: 0 }),
  routes: [
    {
      path: '/tool',
      name: 'Toolbar',
      component: Toolbar
    },
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/left',
      name: 'Left',
      component: Left
    },
    {
      path: '/hi',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/symbol',
      name: 'Symbols',
      component: Symbols
    },
    {
      path: '/content',
      name: 'Content',
      component: Content
    },
    {
      path: '/approval',
      name: 'Approval',
      component: Approval
    },
    {
      path: '/app',
      name: 'Application',
      component: Application
    }
  ]
})

// 注册
Vue.component('my-toolbar', {
  template: '#toolbar-template'
  // template: '<div class="toolbar flex"><div class="first-btn">发起审批</div><div class="division"></div><div class="first-tab active">资源包购买记录</div><div class="first-tab">资源包消耗明细</div><div class="first-tab">抄送我的<span class="prompt">1</span></div></div>'
})

Vue.component('my-leftbar', {
  template: '#leftbar-template'
})

Vue.component('my-content', {
  template: '#content-template'
})

Vue.component('my-approval', {
  template: '#approval-template'
})

Vue.component('my-application', {
  template: '#application-template'
})
// 创建根实例
// new Vue({
//   el: '#example'
// })